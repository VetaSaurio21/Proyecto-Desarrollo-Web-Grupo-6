const { randomBytes, scrypt } = require('node:crypto')
const { promisify } = require('node:util')
const Customer = require('../models/Customer')

const deriveKey = promisify(scrypt)
const clean = (value) => typeof value === 'string' ? value.trim() : ''

async function registerCustomer(req, res) {
  const body = req.body ?? {}
  const nombre = clean(body.nombre)
  const rut = clean(body.rut).toUpperCase()
  const correo = clean(body.correo).toLowerCase()
  const direccion = clean(body.direccion)
  const telefono = clean(body.telefono)
  const { password, confirmarPassword } = body

  if (!nombre || !direccion) {
    return res.status(400).json({ mensaje: 'Completa el nombre y la dirección.' })
  }

  if (!/^[0-9]{7,8}-[0-9K]$/.test(rut)) {
    return res.status(400).json({ mensaje: 'Escribe el RUT sin puntos y con guion.' })
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
    return res.status(400).json({ mensaje: 'Escribe un correo válido.' })
  }

  if (typeof password !== 'string' || password.length < 8 || password.length > 128) {
    return res.status(400).json({ mensaje: 'Usa entre 8 y 128 caracteres en la contraseña.' })
  }

  if (password !== confirmarPassword) {
    return res.status(400).json({ mensaje: 'Las contraseñas no coinciden.' })
  }

  try {
    const salt = randomBytes(16).toString('hex')
    const hash = await deriveKey(password, salt, 64, {
      N: 32768, r: 8, p: 3, maxmem: 64 * 1024 * 1024,
    })

    await Customer.create({
      nombre,
      rut,
      correo,
      direccion,
      telefono,
      passwordHash: `${salt}:${hash.toString('hex')}`,
    })

    return res.status(201).json({ mensaje: 'Cliente registrado correctamente.' })
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ mensaje: 'El RUT o correo ya está registrado.' })
    }

    return res.status(500).json({ mensaje: 'No se pudo guardar el cliente.' })
  }
}

module.exports = { registerCustomer }