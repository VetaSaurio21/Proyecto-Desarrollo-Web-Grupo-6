const { scrypt, timingSafeEqual } = require('node:crypto')
const { promisify } = require('node:util')
const Customer = require('../models/Customer')

const deriveKey = promisify(scrypt)

async function login(req, res) {
  const { correo, password } = req.body ?? {}
  const errorDeIngreso = { mensaje: 'Correo o contraseña incorrectos.' }

  if (
    typeof correo !== 'string' ||
    typeof password !== 'string' ||
    password.length < 8 ||
    password.length > 128
  ) {
    return res.status(401).json(errorDeIngreso)
  }

  try {
    const customer = await Customer.findOne({
      correo: correo.trim().toLowerCase(),
    }).select('+passwordHash')

    if (!customer) {
      return res.status(401).json(errorDeIngreso)
    }

    // Usamos la misma configuración que en el registro.
    const [salt, savedHash] = customer.passwordHash.split(':')
    const hash = await deriveKey(password, salt, 64, {
      N: 32768,
      r: 8,
      p: 3,
      maxmem: 64 * 1024 * 1024,
    })

    if (!timingSafeEqual(hash, Buffer.from(savedHash, 'hex'))) {
      return res.status(401).json(errorDeIngreso)
    }

    await promisify(req.session.regenerate.bind(req.session))()
    req.session.user = {
      id: customer.id,
      nombre: customer.nombre,
      correo: customer.correo,
    }
    await promisify(req.session.save.bind(req.session))()

    return res.json({ usuario: req.session.user })
  } catch {
    return res.status(500).json({ mensaje: 'No se pudo iniciar sesión.' })
  }
}

function getSession(req, res) {
  if (!req.session.user) {
    return res.status(401).json({ mensaje: 'No hay una sesión activa.' })
  }

  return res.json({ usuario: req.session.user })
}

function logout(req, res) {
  req.session.destroy((error) => {
    if (error) {
      return res.status(500).json({ mensaje: 'No se pudo cerrar sesión.' })
    }

    res.clearCookie('ferreteria.sid')
    return res.status(204).end()
  })
}

module.exports = { login, getSession, logout }