const express = require('express')
const { registerCustomer } = require('../controllers/customerController')
const { login, getSession, logout } = require('../controllers/sessionController')

const router = express.Router()

router.post('/clientes', registerCustomer)
router.post('/sesion', login)
router.get('/sesion', getSession)
router.delete('/sesion', logout)

module.exports = router