const mongoose = require('mongoose')

const customerSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true },
    rut: { type: String, required: true, unique: true, trim: true },
    correo: { type: String, required: true, unique: true, trim: true, lowercase: true },
    direccion: { type: String, required: true, trim: true },
    telefono: { type: String, trim: true },
    passwordHash: { type: String, required: true, select: false },
  },
  { timestamps: true }
)

module.exports = mongoose.model('Customer', customerSchema)