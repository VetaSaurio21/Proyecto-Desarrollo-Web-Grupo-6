const session = require('express-session')
const { randomBytes } = require('node:crypto')
const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const Customer = require('./models/Customer')
const customerRoutes = require('./routes/customerRoutes')

const app = express()

app.use(cors({
  origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
  credentials: true,
}))
app.use(express.json())

app.use(session({
  name: 'ferreteria.sid',
  secret: randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax' },
}))

app.get('/api/health', (req, res) => {
  res.json({ mensaje: 'Servidor funcionando y conectado a MongoDB' })
})

app.use('/api', customerRoutes)

async function startServer() {
  try {
    await mongoose.connect('mongodb://127.0.0.1:27017/ferreteria')
    await Customer.init()
    console.log('MongoDB conectado')

    app.listen(4000, '127.0.0.1', () => {
      console.log('Servidor listo en http://127.0.0.1:4000')
    })
  } catch (error) {
    console.error('No se pudo iniciar el servidor:', error.message)
    await mongoose.disconnect()
    process.exitCode = 1
  }
}

startServer()