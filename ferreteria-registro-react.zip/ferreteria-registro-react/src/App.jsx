import { useEffect, useState } from 'react'
import Header from './components/Header.jsx'
import FormularioRegistro from './components/FormularioRegistro.jsx'
import Beneficios from './components/Beneficios.jsx'
import LoginForm from './components/LoginForm.jsx'
import Footer from './components/Footer.jsx'
import './App.css'

const URL_SESION = 'http://127.0.0.1:4000/api/sesion'

function App() {
  const [usuario, setUsuario] = useState(null)

  useEffect(() => {
    async function consultarSesion() {
      try {
        const respuesta = await fetch(URL_SESION, {
          credentials: 'include',
        })

        if (respuesta.ok) {
          const datos = await respuesta.json()
          setUsuario(datos.usuario)
        }
      } catch {
        // El formulario de ingreso sigue visible si el servidor no responde.
      }
    }

    consultarSesion()
  }, [])

  async function cerrarSesion() {
    try {
      const respuesta = await fetch(URL_SESION, {
        method: 'DELETE',
        credentials: 'include',
      })

      if (!respuesta.ok) {
        throw new Error('No se pudo cerrar la sesión')
      }

      setUsuario(null)
    } catch {
      window.alert('No se pudo cerrar la sesión. Inténtalo de nuevo.')
    }
  }

  return (
    <>
      <Header usuario={usuario} onLogout={cerrarSesion} />

      <main className="registro-layout">
        <section className="columna-formulario" id="registro">
          <h1>¿Aún no estás registrado?</h1>
          <p>Crea tu cuenta para comprar, cotizar y revisar tus pedidos.</p>

          <FormularioRegistro />
          {!usuario && <LoginForm onLogin={setUsuario} />}
        </section>

        <Beneficios />
      </main>

      <Footer />
    </>
  )
}

export default App