function Header({ usuario, onLogout }) {
  return (
    <header className="barra-superior" id="inicio">
      <img
        src="/img/logo.png"
        alt="Logo Ferretería El Constructor"
        className="logo"
      />

      <nav className="menu">
        <a href="#contacto">Contacto</a>
        <a href="#registro">Registro</a>
        <a href="#beneficio">Beneficios</a>
      </nav>
      {usuario && (
  <div style={{ color: 'white' }}>
    <p>Hola, {usuario.nombre}</p>
    <button type="button" onClick={onLogout}>
      Cerrar sesión
    </button>
  </div>
)}
    </header>
  )
}

export default Header
