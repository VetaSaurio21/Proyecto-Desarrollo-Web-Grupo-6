import { useState } from 'react'

export default function LoginForm({ onLogin }) {
  const [mensaje, setMensaje] = useState('')
  const [enviando, setEnviando] = useState(false)

  async function ingresar(evento) {
    evento.preventDefault()
    if (enviando) return

    const datos = Object.fromEntries(new FormData(evento.currentTarget))
    setMensaje('')
    setEnviando(true)

    try {
      const respuesta = await fetch('http://127.0.0.1:4000/api/sesion', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos),
      })

      const resultado = await respuesta.json()

      if (!respuesta.ok) {
        setMensaje(resultado.mensaje || 'No se pudo iniciar sesión.')
        return
      }

      onLogin(resultado.usuario)
    } catch {
      setMensaje('No se pudo conectar con el servidor.')
    } finally {
      setEnviando(false)
    }
  }

  return (
    <form onSubmit={ingresar}>
      <h2>Iniciar sesión</h2>

      <label htmlFor="login-correo">Correo electrónico</label>
      <input id="login-correo" name="correo" type="email" required />

      <label htmlFor="login-password">Contraseña</label>
      <input id="login-password" name="password" type="password" required />

      <button type="submit" disabled={enviando}>
        {enviando ? 'Ingresando…' : 'Ingresar'}
      </button>

      {mensaje && <p role="status">{mensaje}</p>}
    </form>
  )
}