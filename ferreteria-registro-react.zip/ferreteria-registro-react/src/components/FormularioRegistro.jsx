import { useState } from 'react'

function FormularioRegistro() {
  const [mensaje, setMensaje] = useState('')
  const [enviando, setEnviando] = useState(false)

async function registrar(evento) {
  evento.preventDefault()
  if (enviando) return

  const formulario = evento.currentTarget
  const datos = new FormData(formulario)
  const cliente = Object.fromEntries(datos)
  const nombre = cliente.nombre.trim()
  const rut = cliente.rut.trim().toUpperCase()
  const { password, confirmarPassword } = cliente

  if (!nombre) {
    setMensaje('Escribe tu nombre completo.')
    return
  }

  if (!/^[0-9]{7,8}-[0-9K]$/.test(rut)) {
    setMensaje('Escribe el RUT sin puntos y con guion.')
    return
  }

  if (password.length < 8 || password.length > 128) {
    setMensaje('Usa entre 8 y 128 caracteres en la contraseña.')
    return
  }

  if (password !== confirmarPassword) {
    setMensaje('Las contraseñas no coinciden.')
    return
  }

  setEnviando(true)
  setMensaje('')

  try {
    const respuesta = await fetch('http://127.0.0.1:4000/api/clientes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...cliente, nombre, rut }),
    })

    const resultado = await respuesta.json()
    setMensaje(resultado.mensaje)

    if (respuesta.ok) {
      formulario.reset()
    }
  } catch {
    setMensaje('No se pudo comunicar con el servidor. Comprueba que el backend esté funcionando.')
  } finally {
    setEnviando(false)
  }
}
  return (
    <form onSubmit={registrar}>
      <label htmlFor="nombre">Nombre completo</label>
      <input
        id="nombre"
        name="nombre"
        type="text"
        placeholder="Escribe tu nombre completo"
        required
      />

      <label htmlFor="rut" translate="no">RUT</label>
      <input
        id="rut"
        name="rut"
        type="text"
        placeholder="Ej: 12345678-9"
        required
      />

      <label htmlFor="correo">Correo electrónico</label>
      <input
        id="correo"
        name="correo"
        type="email"
        placeholder="Ej: nombre@correo.cl"
        required
      />

      <label htmlFor="telefono">Teléfono (opcional)</label>
      <input
        id="telefono"
        name="telefono"
        type="tel"
        placeholder="Ej: +56 9 1234 5678"
      />

      <label htmlFor="direccion">Dirección</label>
      <input
        id="direccion"
        name="direccion"
        type="text"
        placeholder="Escribe tu dirección"
        required
      />

      <label htmlFor="password">Contraseña</label>
      <input
        id="password"
        name="password"
        type="password"
        minLength={8}
        maxLength={128}
        required
      />

      <label htmlFor="confirmarPassword">
        Confirmar contraseña
      </label>
      <input
        id="confirmarPassword"
        name="confirmarPassword"
        type="password"
        minLength={8}
        maxLength={128}
        required
      />

      <button type="submit" disabled={enviando}>
  {enviando ? 'Registrando…' : 'Registrarme'}
</button>

      {mensaje && <p role="status">{mensaje}</p>}
    </form>
  )
}

export default FormularioRegistro