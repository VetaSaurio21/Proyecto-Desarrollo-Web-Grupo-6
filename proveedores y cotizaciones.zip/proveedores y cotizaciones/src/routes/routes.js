import { Router } from "express"

//_---------------------------------------------------------------

import { cliente,mostrarClientes,mostrarCliente,
    eliminarCliente,actualizarCliente
 } from "../controllers/clienteCont.js"

//-----------------------------------------------------------------


 import { registrarProducto,mostrarProductos,mostrarProducto,
    editarProducto,eliminarProducto,sumProducto,resProducto
  } from "../controllers/inventarioCont.js"


//-----------------------------------------------------------------

import {
    registrarProveedor, mostrarProveedores,mostrarProveedor,
    editarProveedor,eliminarProveedor,mostrarProveedorPorRut
} from "../controllers/proveedoresConts.js"


//------------------------------------------------------------------


const router = Router()

//------------------------------------------------------------------

router.post('/cliente',cliente)
router.get('/cliente',mostrarClientes)
router.get('/cliente/:id',mostrarCliente)
router.delete('/cliente/:id',eliminarCliente)
router.put('/cliente/:id',actualizarCliente)

//------------------------------------------------

router.post('/producto',registrarProducto)
router.get('/producto', mostrarProductos)
router.get('/producto/:id',mostrarProducto)
router.put('/producto/:id', editarProducto)
router.delete('/producto/:id', eliminarProducto)
router.put('/producto/:id/sumar',sumProducto)
router.put('/producto/:id/restar', resProducto)

//----------------------------------------------------------------------

router.post('/proveedor', registrarProveedor)
router.get('/proveedor', mostrarProveedores)
router.get('/proveedor/:id', mostrarProveedor)
router.put('/proveedor/:id', editarProveedor)
router.delete('/proveedor/:id', eliminarProveedor)
router.get('/proveedor/rut/:rut', mostrarProveedorPorRut)


export default router
