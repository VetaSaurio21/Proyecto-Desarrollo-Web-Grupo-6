import mongoose from 'mongoose'

export const connectDB = async () =>{
  try{
    await mongoose.connect('mongodb://localhost:27017/PruebaDB')
    console.log('Base datos Conectada')
  }catch(error){
    console.log(error)
  }
}
