import Producto from "../models/producto.js"

export const registrarProducto= async(req,res)=>{
    try {
        const {codigo,nombre,descripcion,imagen,categoria,marca,proveedor,
            precio,costo,stock,stockMinimo}=req.body
        const producto = new Producto({
            codigo,
            nombre,
            descripcion,
            imagen,
            categoria,
            marca,
            proveedor,
            precio,
            costo,
            stock,
            stockMinimo
        })

        await producto.save()
        res.status(200).json(producto)
    } catch (error) {
        console.error("Error en registrarProducto:", error)
        res.status(400).json({
            mensaje: "Error al registrar el producto",
            error: error.message
        })

    }
}

//_________________________________________________________________________

export const mostrarProducto = async (req, res) => {
    try {
        const producto = await Producto.findById(req.params.id)
        if (!producto) {
            return res.status(404).json({
                 mensaje: "Producto no encontrado" })
        }
        res.status(200).json(producto)
    } catch (error) {
        console.error("Error en mostrarProducto:", error)
        res.status(400).json({
             mensaje: "Error al buscar el producto",
             error: error.message })
    }
}

//___________________________________________________________________

export const mostrarProductos = async (req,res)=>{
    try {
        const productos=await Producto.find()
        res.status(200).json(productos)
    } catch (error) {
        console.error("Error en mostrarProductos:", error)
        res.status(500).json({
            mensaje: "Error al listar los productos",
            error: error.message

        })

    }
}

//_______________________________________________________________________

export const editarProducto = async (req, res) => {
    try {
        const producto = await Producto.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        )
        if (!producto) {
            return res.status(404).json({ mensaje: "Producto no encontrado" })
        }
        res.status(200).json(producto)
    } catch (error) {
        console.error("Error en editarProducto:", error)
        res.status(400).json({ mensaje: "Error al actualizar el producto",
             error: error.message })
    }
}

//___________________________________________________________________________________

export const eliminarProducto = async (req, res) => {
    try {
        const producto = await Producto.findByIdAndDelete(req.params.id)
        if (!producto) {
            return res.status(404).json({ mensaje: "Producto no encontrado" })
        }
        res.status(200).json({ mensaje: "Producto eliminado" })
    } catch (error) {
        console.error("Error en eliminarProducto:", error)
        res.status(400).json({ mensaje: "Error al eliminar el producto", error: error.message })
    }
}

//____________________________________________________________________________________
export const sumProducto = async (req, res) => {
    try {
        const producto = await Producto.findByIdAndUpdate(
            req.params.id,
            { $inc: { stock: 1 } },
            { new: true }
        )
        if (!producto) {
            return res.status(404).json({ mensaje: "Producto no encontrado" })
        }
        res.status(200).json(producto)
    } catch (error) {
        console.error("Error en sumProducto:", error)
        res.status(400).json({ mensaje: "Error al sumar stock", error: error.message })
    }
}

//______________________________________________________________________________________

export const resProducto = async (req, res) => {
    try {
        const producto = await Producto.findByIdAndUpdate(
            req.params.id,
            { $inc: { stock: -1 } },
            { new: true }
        )
        if (!producto) {
            return res.status(404).json({ mensaje: "Producto no encontrado" })
        }
        res.status(200).json(producto)
    } catch (error) {
        console.error("Error en resProducto:", error)
        res.status(400).json({ mensaje: "Error al restar stock", error: error.message })
    }
}
