import Proveedor from "../models/proveedor.js"

//----------------------------------------------------------

export const registrarProveedor = async (req, res) => {
    try {
        const { nombre, rut, contacto } = req.body

        const proveedor = new Proveedor({ nombre, rut, contacto })
        await proveedor.save()

        res.status(201).json(proveedor)
    } catch (error) {
        console.error("Error en registrarProveedor:", error)
        res.status(400).json({ mensaje: "Error al registrar el proveedor",
            error: error.message })
    }
}

//-------------------------------------------------------------------------

export const mostrarProveedores = async (req, res) => {
    try {
        const proveedores = await Proveedor.find()
        res.status(200).json(proveedores)
    } catch (error) {
        console.error("Error en mostrarProveedores:", error)
        res.status(500).json({ mensaje: "Error al listar los proveedores",
            error: error.message })
    }
}

//---------------------------------------------------------------------------

export const mostrarProveedor = async (req, res) => {
    try {
        const proveedor = await Proveedor.findById(req.params.id)

        if (!proveedor) {
            return res.status(404).json({ mensaje: "Proveedor no encontrado" })
        }

        res.status(200).json(proveedor)
    } catch (error) {
        console.error("Error en mostrarProveedor:", error)
        res.status(400).json({ mensaje: "Error al buscar el proveedor", error: error.message })
    }
}

//---------------------------------------------------------------------------------------------

export const editarProveedor = async (req, res) => {
    try {
        const proveedor = await Proveedor.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        )

        if (!proveedor) {
            return res.status(404).json({ mensaje: "Proveedor no encontrado" })
        }

        res.status(200).json(proveedor)
    } catch (error) {
        console.error("Error en editarProveedor:", error)
        res.status(400).json({ mensaje: "Error al actualizar el proveedor", error: error.message })
    }
}

//--------------------------------------------------------------------------------------------------

export const eliminarProveedor = async (req, res) => {
    try {
        const proveedor = await Proveedor.findByIdAndDelete(req.params.id)

        if (!proveedor) {
            return res.status(404).json({ mensaje: "Proveedor no encontrado" })
        }

        res.status(200).json({ mensaje: "Proveedor eliminado" })
    } catch (error) {
        console.error("Error en eliminarProveedor:", error)
        res.status(400).json({ mensaje: "Error al eliminar el proveedor", error: error.message })
    }
}

export const mostrarProveedorPorRut = async (req, res) => {
    try {
        const proveedor = await Proveedor.findOne({ rut: req.params.rut })

        if (!proveedor) {
            return res.status(404).json({ mensaje: "Proveedor no encontrado" })
        }

        res.status(200).json(proveedor)
    } catch (error) {
        console.error("Error en mostrarProveedorPorRut:", error)
        res.status(500).json({ mensaje: "Error al buscar el proveedor por RUT", error: error.message })
    }
}


