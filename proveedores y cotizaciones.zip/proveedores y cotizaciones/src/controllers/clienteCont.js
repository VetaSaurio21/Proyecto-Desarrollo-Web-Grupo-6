import Cliente from "../models/cliente.js"

// Registrar Cliente
export const cliente = async (req, res) => {
  try {
    const { nombre, rut, edad } = req.body

    const nuevoCliente = new Cliente({
      nombre,
      rut,
      edad
    })

    await nuevoCliente.save()

    res.status(201).json({
      mensaje: "Cliente registrado correctamente",
      cliente: nuevoCliente
    })

  } catch (error) {
    console.error("Error en cliente:", error)

    res.status(400).json({
      mensaje: "Error al registrar el cliente",
      error: error.message
    })
  }
}

// Mostrar Clientes
export const mostrarClientes = async (req, res) => {
  try {
    const clientes = await Cliente.find()

    res.status(200).json(clientes)

  } catch (error) {
    console.error("Error en mostrarClientes:", error)

    res.status(500).json({
      mensaje: "Error al obtener los clientes",
      error: error.message
    })
  }
}

// Mostrar un solo cliente
export const mostrarCliente = async (req, res) => {
  try {
    const { id } = req.params

    const cliente = await Cliente.findById(id)

    if (!cliente) {
      return res.status(404).json({
        mensaje: "Cliente no encontrado"
      })
    }

    res.status(200).json(cliente)

  } catch (error) {
    console.error("Error en mostrarCliente:", error)

    res.status(400).json({
      mensaje: "Error al buscar el cliente",
      error: error.message
    })
  }
}

// Eliminar Cliente
export const eliminarCliente = async (req, res) => {
  try {
    const { id } = req.params

    const clienteEliminado = await Cliente.findByIdAndDelete(id)

    if (!clienteEliminado) {
      return res.status(404).json({
        mensaje: "Cliente no encontrado"
      })
    }

    res.status(200).json({
      mensaje: "Cliente eliminado correctamente",
      cliente: clienteEliminado
    })

  } catch (error) {
    console.error("Error en eliminarCliente:", error)

    res.status(400).json({
      mensaje: "Error al eliminar el cliente",
      error: error.message
    })
  }
}

export const actualizarCliente= async(req,res)=>{
  try {
    const cliente = await Cliente.findByIdAndUpdate(
      req.params.id,
      req.body,
      {new:true, runValidators:true}
    )
    if (!cliente){
      return res.status(404).json({
        mensaje: "Cliente no encontrado"
      })
    }
    res.status(200).json(cliente)
  } catch (error) {
    console.error("Error en actualizarCliente:", error)

    res.status(400).json({
      mensaje:"Error al actualizar el cliente",
      error: error.message
    })

  }

}






