import mongoose from "mongoose"

const productoEsquema = new mongoose.Schema({
    
    codigo:{
        type: String,
        required: true,
        unique: true
    },

    nombre:{
        type:String,
        required: true

    },

    descripcion:{
        type:String,
        default:""
    },

    imagen:{
        type:String,
        default: ""
    },

    categoria:{
        type: String,
        required:true
    },

    proveedor:{
        type: String,
        default: ""
    },

    precio:{
        type:Number,
        required:true,
        min:0
    },

    costo:{
        type:Number,
        default: 0,
        min:0
    },

    stock:{
        type:Number,
        default:0,
        min:0
    },

    stockMinimo:{
        type: Number,
        default:0,
        min:0
    }

})

export default mongoose.model("producto",productoEsquema)