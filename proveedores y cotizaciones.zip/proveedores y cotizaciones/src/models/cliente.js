import mongoose from "mongoose"

const esquema = new mongoose.Schema({
  nombre:{
    type: String,
    required:true
  },
  rut: {
    type: String,
    required: true,
    unique: true
  }, 
  edad: {
    type: Number,
    required:true
  }   
})

export default mongoose.model('Cliente',esquema)
