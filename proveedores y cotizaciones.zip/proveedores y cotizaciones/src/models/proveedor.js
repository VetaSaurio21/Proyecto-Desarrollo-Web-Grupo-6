// models/proveedor.js
import mongoose from "mongoose"

const proveedorEsquema = new mongoose.Schema({
    nombre: { type: String, required: true, trim: true },
    rut: { type: String, required: true, unique: true, trim: true },
    contacto: {
        nombre: { type: String, default: "" },
        email: { type: String, default: "" },
        telefono: { type: String, default: "" }
    }
})

export default mongoose.model("proveedores", proveedorEsquema)
