import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // En desarrollo, todo lo que empiece con /api se reenvía al backend (puerto 4000).
  // Así el frontend llama a "/api/pedidos" sin problemas de CORS ni URLs absolutas.
  server: {
    proxy: {
      '/api': 'http://localhost:4000',
    },
  },
})
