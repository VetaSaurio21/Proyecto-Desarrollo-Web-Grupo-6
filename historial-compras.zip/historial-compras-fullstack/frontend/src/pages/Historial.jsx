import { useEffect, useMemo, useState } from "react"
import Header from "../components/Header"
import Footer from "../components/Footer"
import ResumenCard from "../components/ResumenCard"
import Pestanas from "../components/Pestanas"
import Filtros from "../components/Filtros"
import TablaRegistros from "../components/TablaRegistros"
import ModalDetalle from "../components/ModalDetalle"
import {
  getPedidos,
  getCotizaciones,
  getCliente,
  getEstados,
} from "../services/api"
import {
  calcularTotal,
  formatearFecha,
  formatearPrecio,
  resumirProductos,
} from "../utils/formato"

// Busca el texto que se muestra para un estado ("preparacion" -> "En preparación").
// Si no lo encuentra, devuelve el mismo valor para no romper la vista.
function textoDelEstado(listaEstados, valor) {
  const encontrado = listaEstados.find((e) => e.valor === valor)
  return encontrado ? encontrado.texto : valor
}

const avisosCotizacion = {
  pendiente:
    "Un vendedor está revisando esta cotización. Te avisaremos por correo cuando tenga respuesta.",
  vencida:
    "Esta cotización ya no está vigente. Solicita una nueva para actualizar precios y stock.",
}

// Años que aparecen en una lista, del más reciente al más antiguo
function obtenerAnios(registros) {
  const anios = registros.map((r) => r.fecha.slice(0, 4))
  return [...new Set(anios)].sort().reverse()
}

function Historial() {
  // Datos que llegan del backend
  const [pedidos, setPedidos] = useState([])
  const [cotizaciones, setCotizaciones] = useState([])
  const [cliente, setCliente] = useState(null)
  const [estados, setEstados] = useState({ pedido: [], cotizacion: [] })

  // Estado de la carga desde la API
  const [cargando, setCargando] = useState(true)
  const [error, setError] = useState(null)
  const [intento, setIntento] = useState(0) // subir este número reintenta la carga

  // Estado de la interfaz (filtros, pestaña y ventana de detalle)
  const [pestanaActiva, setPestanaActiva] = useState("pedidos")
  const [busqueda, setBusqueda] = useState("")
  const [estado, setEstado] = useState("todos")
  const [anio, setAnio] = useState("todos")
  const [registroSeleccionado, setRegistroSeleccionado] = useState(null)

  // Carga inicial: pide los cuatro recursos a la API al mismo tiempo.
  useEffect(() => {
    let activo = true // evita actualizar el estado si el componente se desmontó

    async function cargar() {
      try {
        setCargando(true)
        setError(null)
        const [p, c, cli, est] = await Promise.all([
          getPedidos(),
          getCotizaciones(),
          getCliente(),
          getEstados(),
        ])
        if (!activo) return
        setPedidos(p)
        setCotizaciones(c)
        setCliente(cli)
        setEstados(est)
      } catch (e) {
        if (activo) setError(e.message)
      } finally {
        if (activo) setCargando(false)
      }
    }

    cargar()
    return () => {
      activo = false
    }
  }, [intento])

  // Pedidos y cotizaciones quedan con la misma forma para usar los mismos componentes.
  // useMemo evita rehacer el cálculo en cada tecla que escribe el usuario.
  const listaPedidos = useMemo(
    () =>
      pedidos.map((pedido) => ({
        ...pedido,
        extra: pedido.entrega,
        textoEstado: textoDelEstado(estados.pedido, pedido.estado),
        total: calcularTotal(pedido.productos),
        resumen: resumirProductos(pedido.productos),
        aviso:
          pedido.estado === "pendiente"
            ? "Este pedido aún no registra pago. Puedes pagarlo en tienda o contactar a un vendedor."
            : null,
      })),
    [pedidos, estados]
  )

  const listaCotizaciones = useMemo(
    () =>
      cotizaciones.map((cotizacion) => ({
        ...cotizacion,
        extra: formatearFecha(cotizacion.vigencia),
        textoEstado: textoDelEstado(estados.cotizacion, cotizacion.estado),
        total: calcularTotal(cotizacion.productos),
        resumen: resumirProductos(cotizacion.productos),
        aviso: avisosCotizacion[cotizacion.estado] || null,
      })),
    [cotizaciones, estados]
  )

  // Lo que cambia entre una pestaña y la otra
  const configuracion = useMemo(
    () => ({
      pedidos: {
        registros: listaPedidos,
        tituloId: "N° Pedido",
        tituloExtra: "Entrega",
        opcionesEstado: estados.pedido,
        placeholder: "N° de pedido o producto",
      },
      cotizaciones: {
        registros: listaCotizaciones,
        tituloId: "N° Cotización",
        tituloExtra: "Válida hasta",
        opcionesEstado: estados.cotizacion,
        placeholder: "N° de cotización o producto",
      },
    }),
    [listaPedidos, listaCotizaciones, estados]
  )

  // Datos para las tarjetas de resumen
  const resumen = useMemo(() => {
    const totalComprado = listaPedidos
      .filter((p) => p.estado !== "pendiente")
      .reduce((suma, p) => suma + p.total, 0)
    const pedidosEntregados = listaPedidos.filter(
      (p) => p.estado === "entregado"
    ).length
    const cotizacionesPendientes = listaCotizaciones.filter(
      (c) => c.estado === "pendiente"
    ).length
    return { totalComprado, pedidosEntregados, cotizacionesPendientes }
  }, [listaPedidos, listaCotizaciones])

  function limpiarFiltros() {
    setBusqueda("")
    setEstado("todos")
    setAnio("todos")
  }

  function cambiarPestana(id) {
    setPestanaActiva(id)
    limpiarFiltros() // los estados de pedidos y cotizaciones son distintos
  }

  // Mientras la API responde
  if (cargando) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col items-center justify-center px-4 py-16 text-center">
          <p className="animate-pulse text-5xl" aria-hidden="true">⏳</p>
          <p className="mt-4 font-titulo text-xl font-semibold text-marino">
            Cargando tu historial...
          </p>
        </main>
        <Footer />
      </div>
    )
  }

  // Si la API falló (por ejemplo, el backend está apagado)
  if (error) {
    return (
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="mx-auto flex w-full max-w-6xl flex-1 flex-col items-center justify-center px-4 py-16 text-center">
          <p className="text-5xl" aria-hidden="true">⚠️</p>
          <h1 className="mt-4 font-titulo text-2xl font-bold text-marino">
            No se pudo cargar el historial
          </h1>
          <p className="mt-2 max-w-md text-gray-600">
            Revisa que el servidor (backend) esté encendido y vuelve a intentar.
          </p>
          <p className="mt-1 text-sm text-gray-400">{error}</p>
          <button
            type="button"
            onClick={() => setIntento((n) => n + 1)}
            className="mt-6 rounded-md bg-dorado px-5 py-2 font-bold text-marino transition-colors hover:bg-marino-claro hover:text-white"
          >
            Reintentar
          </button>
        </main>
        <Footer />
      </div>
    )
  }

  const actual = configuracion[pestanaActiva]

  // Se filtra en cada render a partir del estado: no hace falta tocar el DOM
  const texto = busqueda.trim().toLowerCase()

  const registrosFiltrados = actual.registros.filter((registro) => {
    const coincideTexto =
      registro.id.toLowerCase().includes(texto) ||
      registro.productos.some((p) => p.nombre.toLowerCase().includes(texto))
    const coincideEstado = estado === "todos" || registro.estado === estado
    const coincideAnio = anio === "todos" || registro.fecha.startsWith(anio)

    return coincideTexto && coincideEstado && coincideAnio
  })

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:py-10">
        {/* Título */}
        <section className="mb-8">
          <p className="text-sm font-semibold uppercase tracking-widest text-dorado-oscuro">
            Mi cuenta
          </p>
          <h1 className="font-titulo text-3xl font-bold text-marino sm:text-4xl">
            Historial de compras
          </h1>
          <p className="mt-2 text-gray-600">
            Revisa los pedidos y las cotizaciones que has realizado
            {cliente?.nombre ? `, ${cliente.nombre}` : ""}.
          </p>
        </section>

        {/* Resumen */}
        <section className="mb-10 grid gap-4 md:grid-cols-3">
          <ResumenCard
            icono="📦"
            titulo="Pedidos realizados"
            valor={listaPedidos.length}
            detalle={`${resumen.pedidosEntregados} entregados`}
          />
          <ResumenCard
            icono="🧾"
            titulo="Total comprado"
            valor={formatearPrecio(resumen.totalComprado)}
            detalle="En pedidos pagados"
          />
          <ResumenCard
            icono="📋"
            titulo="Cotizaciones pendientes"
            valor={resumen.cotizacionesPendientes}
            detalle="Esperando respuesta"
          />
        </section>

        {/* Pedidos / cotizaciones */}
        <section>
          <Pestanas
            pestanas={[
              { id: "pedidos", texto: "Pedidos", cantidad: listaPedidos.length },
              {
                id: "cotizaciones",
                texto: "Cotizaciones",
                cantidad: listaCotizaciones.length,
              },
            ]}
            activa={pestanaActiva}
            onCambiar={cambiarPestana}
          />

          <div className="space-y-6 rounded-b-xl rounded-tr-xl bg-white p-4 shadow-md sm:p-6">
            <Filtros
              textoBusqueda={busqueda}
              placeholder={actual.placeholder}
              estado={estado}
              anio={anio}
              opcionesEstado={actual.opcionesEstado}
              opcionesAnio={obtenerAnios(actual.registros)}
              onBuscar={setBusqueda}
              onCambiarEstado={setEstado}
              onCambiarAnio={setAnio}
              onLimpiar={limpiarFiltros}
            />

            <p className="text-sm text-gray-500">
              Mostrando {registrosFiltrados.length} de {actual.registros.length}
            </p>

            <TablaRegistros
              registros={registrosFiltrados}
              tituloId={actual.tituloId}
              tituloExtra={actual.tituloExtra}
              onVerDetalle={setRegistroSeleccionado}
            />
          </div>
        </section>
      </main>

      <Footer />

      {/* La ventana de detalle solo existe mientras hay un registro elegido */}
      {registroSeleccionado && (
        <ModalDetalle
          registro={registroSeleccionado}
          tituloExtra={actual.tituloExtra}
          onCerrar={() => setRegistroSeleccionado(null)}
        />
      )}
    </div>
  )
}

export default Historial
