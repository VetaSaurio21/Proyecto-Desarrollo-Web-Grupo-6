// Colores de cada estado (presentación). El texto de cada estado
// ("Entregado", "En preparación", etc.) ahora llega desde el backend.
export const coloresEstado = {
  entregado: "bg-green-100 text-green-800",
  aprobada: "bg-green-100 text-green-800",
  preparacion: "bg-blue-100 text-blue-800",
  pendiente: "bg-amber-100 text-amber-800",
  vencida: "bg-red-100 text-red-800",
}
