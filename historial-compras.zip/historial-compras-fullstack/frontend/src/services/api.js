// Punto único donde el frontend habla con el backend.
// En desarrollo se usa "/api" (lo reenvía Vite al puerto 4000).
// Si algún día el backend queda en otra dirección, se cambia con la
// variable VITE_API_URL en un archivo .env, sin tocar el resto del código.
const BASE = import.meta.env.VITE_API_URL || "/api"

// Hace la petición y controla los errores en un solo lugar.
async function pedir(ruta) {
  const respuesta = await fetch(`${BASE}${ruta}`)
  if (!respuesta.ok) {
    throw new Error(`Error ${respuesta.status} al pedir ${ruta}`)
  }
  return respuesta.json()
}

export const getPedidos = () => pedir("/pedidos")
export const getCotizaciones = () => pedir("/cotizaciones")
export const getCliente = () => pedir("/cliente")
export const getEstados = () => pedir("/estados")
