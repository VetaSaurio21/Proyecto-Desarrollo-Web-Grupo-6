# Historial de Compras · Ferretería El Constructor (Full Stack)

Módulo **"Mis compras"** del Sistema de Ventas On-line de la Ferretería El Constructor
(Caso 6, ramo Desarrollo Web y Móvil), ahora con **backend y base de datos**.

El proyecto tiene dos partes:

```
historial-compras-fullstack/
├── backend/     API REST con Node.js, Express y MongoDB (Mongoose)
└── frontend/    Página en React + Vite + Tailwind (la de la Solemne 2)
```

Antes, el frontend mostraba datos escritos a mano en archivos `.js`.
Ahora esos datos (pedidos, cotizaciones, cliente) viven en **MongoDB**, el backend
los entrega por una API y el frontend los pide con `fetch`.

---

## Qué necesitas instalado

- **Node.js** 18 o superior (recomendado 20+).
- **MongoDB**. Dos opciones, elige una:
  - **Local**: instala MongoDB Community Server en tu computador. Queda escuchando en
    `mongodb://127.0.0.1:27017`.
  - **MongoDB Atlas** (en la nube, gratis): crea un cluster y copia la cadena de
    conexión `mongodb+srv://...`.

---

## Cómo levantar el proyecto (paso a paso)

Necesitas **dos terminales** abiertas: una para el backend y otra para el frontend.

### 1) Backend (API + base de datos)

```bash
cd backend
npm install                 # instala las dependencias
cp .env.example .env        # crea tu archivo de configuración
```

Abre el archivo `.env` y revisa `MONGODB_URI`:
- Si usas MongoDB local, déjalo como está.
- Si usas Atlas, pega ahí tu cadena de conexión.

Carga los datos iniciales en la base y enciende el servidor:

```bash
npm run seed                # inserta pedidos, cotizaciones y cliente en MongoDB
npm run dev                 # levanta la API en http://localhost:4000
```

Para comprobar que la API responde, abre en el navegador:
`http://localhost:4000/api/health` → debe mostrar `{"ok":true,...}`.

### 2) Frontend (la página)

En **otra terminal**:

```bash
cd frontend
npm install
npm run dev                 # abre http://localhost:5173
```

Listo. La página carga el historial desde la API. El `vite.config.js` reenvía todo lo
que empieza con `/api` al backend del puerto 4000, así que no hay que configurar nada más.

> Si abres el frontend con el backend apagado, la página muestra un aviso
> "No se pudo cargar el historial" con un botón **Reintentar**.

---

## La API

Base: `http://localhost:4000/api`

| Método | Ruta                   | Qué devuelve                                   |
|--------|------------------------|------------------------------------------------|
| GET    | `/health`              | Estado de la API                               |
| GET    | `/pedidos`             | Lista de pedidos (del más nuevo al más antiguo)|
| GET    | `/pedidos/:codigo`     | Un pedido por su número (ej. `FC-0187`)        |
| GET    | `/cotizaciones`        | Lista de cotizaciones                          |
| GET    | `/cotizaciones/:codigo`| Una cotización por su número (ej. `COT-0044`)  |
| GET    | `/cliente`             | Datos del cliente                              |
| GET    | `/estados`             | Textos de los estados (pedido y cotización)    |

Ejemplo de un pedido que entrega la API:

```json
{
  "id": "FC-0187",
  "fecha": "2026-08-28",
  "entrega": "Despacho a domicilio",
  "estado": "preparacion",
  "productos": [
    { "nombre": "Taladro inalámbrico 20V", "cantidad": 1, "precio": 64990 }
  ]
}
```

---

## Cómo está armado

**Backend** (`backend/src/`)
- `server.js`: conecta a MongoDB y enciende el servidor.
- `app.js`: configura Express (CORS, JSON, rutas, manejo de errores).
- `config/db.js`: conexión con Mongoose.
- `models/`: esquemas de `Pedido`, `Cotizacion`, `Cliente` y el subdocumento `Producto`.
- `controllers/`: la lógica de cada ruta (buscar en la base y responder).
- `routes/`: define las URL de la API.
- `data/seed-data.js`: los datos iniciales.
- `seed/seed.js`: carga esos datos en MongoDB.

**Frontend** (`frontend/src/`)
- `services/api.js`: funciones que hablan con la API (`getPedidos`, etc.).
- `pages/Historial.jsx`: pide los datos al cargar (`useEffect`) y los guarda en estado
  (`useState`), con pantallas de "cargando" y de "error".
- `components/`: los mismos componentes reutilizables de la Solemne 2.

---

## Notas

- Las fechas se guardan como texto `"AAAA-MM-DD"` para mostrarlas y filtrarlas tal cual,
  sin que la zona horaria cambie el día.
- El número visible del pedido (`FC-0187`) se guarda en la base como `codigo` y la API
  lo entrega con el nombre `id`, que es lo que espera el frontend.
