# Backend · Historial de Compras

API REST con **Node.js + Express + MongoDB (Mongoose)** para el módulo Historial de compras.

## Instalación

```bash
npm install
cp .env.example .env     # ajusta MONGODB_URI si usas Atlas
```

## Comandos

| Comando        | Qué hace                                             |
|----------------|------------------------------------------------------|
| `npm run seed` | Carga los datos iniciales en MongoDB (borra y re-inserta) |
| `npm run dev`  | Levanta la API con recarga automática (puerto 4000)  |
| `npm start`    | Levanta la API en modo normal                        |

## Variables de entorno (`.env`)

```
PORT=4000
MONGODB_URI=mongodb://127.0.0.1:27017/ferreteria_historial
```

## Rutas

- `GET /api/health`
- `GET /api/pedidos` · `GET /api/pedidos/:codigo`
- `GET /api/cotizaciones` · `GET /api/cotizaciones/:codigo`
- `GET /api/cliente`
- `GET /api/estados`

> Primero `npm run seed` (una vez), después `npm run dev`.
