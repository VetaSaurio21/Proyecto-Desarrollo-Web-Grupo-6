// Envuelve un controlador asíncrono para que cualquier error llegue al
// manejador de errores de Express sin escribir try/catch en cada ruta.
export function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next)
}
