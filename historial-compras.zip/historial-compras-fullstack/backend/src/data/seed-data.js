// Datos iniciales del módulo Historial de compras.
// El script de "seed" (src/seed/seed.js) los carga en MongoDB.
// Son los mismos datos que usaba el frontend en la Solemne 2, pero ahora viven
// en la base de datos. El campo "codigo" (FC-0187, COT-0044) es el número visible
// del pedido o cotización; en la API se expone con el nombre "id".

export const pedidos = [
  {
    codigo: "FC-0187",
    fecha: "2026-08-28",
    entrega: "Despacho a domicilio",
    estado: "preparacion",
    productos: [
      { nombre: "Taladro inalámbrico 20V", cantidad: 1, precio: 64990 },
      { nombre: "Set de brocas para metal", cantidad: 1, precio: 11990 },
      { nombre: "Cinta métrica 5 m", cantidad: 1, precio: 9970 },
    ],
  },
  {
    codigo: "FC-0175",
    fecha: "2026-08-12",
    entrega: "Retiro en tienda",
    estado: "entregado",
    productos: [
      { nombre: "Pintura látex 4 L", cantidad: 3, precio: 29990 },
      { nombre: "Rodillo antigota", cantidad: 2, precio: 6990 },
      { nombre: "Cinta de enmascarar", cantidad: 2, precio: 3430 },
    ],
  },
  {
    codigo: "FC-0166",
    fecha: "2026-07-30",
    entrega: "Despacho a domicilio",
    estado: "entregado",
    productos: [
      { nombre: "Cemento gris 25 kg", cantidad: 7, precio: 6490 },
      { nombre: "Saco de arena", cantidad: 8, precio: 2900 },
    ],
  },
  {
    codigo: "FC-0154",
    fecha: "2026-07-05",
    entrega: "Despacho a domicilio",
    estado: "pendiente",
    productos: [
      { nombre: "Ampolleta LED 9W", cantidad: 10, precio: 1990 },
      { nombre: "Cable eléctrico 2,5 mm (rollo)", cantidad: 1, precio: 42990 },
      { nombre: "Interruptor simple", cantidad: 8, precio: 1990 },
    ],
  },
  {
    codigo: "FC-0141",
    fecha: "2026-06-18",
    entrega: "Retiro en tienda",
    estado: "entregado",
    productos: [
      { nombre: "Martillo carpintero", cantidad: 1, precio: 12990 },
      { nombre: 'Clavos 2" (1 kg)', cantidad: 2, precio: 3990 },
      { nombre: "Huincha aisladora", cantidad: 2, precio: 1970 },
    ],
  },
  {
    codigo: "FC-0092",
    fecha: "2025-12-15",
    entrega: "Despacho a domicilio",
    estado: "entregado",
    productos: [
      { nombre: "Set de destornilladores", cantidad: 1, precio: 14990 },
      { nombre: "Alicate universal", cantidad: 1, precio: 9990 },
      { nombre: "Nivel de burbuja", cantidad: 1, precio: 16980 },
    ],
  },
  {
    codigo: "FC-0081",
    fecha: "2025-11-08",
    entrega: "Retiro en tienda",
    estado: "entregado",
    productos: [
      { nombre: "Esmalte sintético 1 galón", cantidad: 2, precio: 27990 },
      { nombre: "Diluyente 1 L", cantidad: 2, precio: 6290 },
    ],
  },
]

export const cotizaciones = [
  {
    codigo: "COT-0044",
    fecha: "2026-08-25",
    vigencia: "2026-09-25",
    estado: "pendiente",
    productos: [
      { nombre: "Perfil metalcon", cantidad: 40, precio: 3490 },
      { nombre: "Tornillos para volcanita (caja)", cantidad: 4, precio: 5990 },
      { nombre: "Plancha de volcanita 15 mm", cantidad: 20, precio: 8957 },
    ],
  },
  {
    codigo: "COT-0039",
    fecha: "2026-08-10",
    vigencia: "2026-09-10",
    estado: "aprobada",
    productos: [
      { nombre: "Cerámica 60x60 (m²)", cantidad: 25, precio: 6290 },
      { nombre: "Adhesivo cerámico 25 kg", cantidad: 5, precio: 4990 },
      { nombre: "Fragüe", cantidad: 5, precio: 1450 },
    ],
  },
  {
    codigo: "COT-0031",
    fecha: "2026-07-02",
    vigencia: "2026-08-02",
    estado: "vencida",
    productos: [
      { nombre: "Andamio modular (cuerpo)", cantidad: 4, precio: 89990 },
      { nombre: "Tablón de andamio", cantidad: 12, precio: 9995 },
      { nombre: "Red de protección", cantidad: 2, precio: 18000 },
    ],
  },
  {
    codigo: "COT-0027",
    fecha: "2026-05-19",
    vigencia: "2026-06-19",
    estado: "aprobada",
    productos: [
      { nombre: "Pintura esmalte 1 galón", cantidad: 5, precio: 34990 },
      { nombre: 'Brocha 3"', cantidad: 6, precio: 4990 },
      { nombre: "Lija (paquete)", cantidad: 10, precio: 2141 },
    ],
  },
]

export const cliente = {
  nombre: "Juan Pérez",
}

// Estados posibles y el texto que se muestra en pantalla.
// "valor" es lo que se guarda; "texto" es lo que lee el usuario.
export const estados = {
  pedido: [
    { valor: "entregado", texto: "Entregado" },
    { valor: "preparacion", texto: "En preparación" },
    { valor: "pendiente", texto: "Pendiente de pago" },
  ],
  cotizacion: [
    { valor: "pendiente", texto: "Pendiente" },
    { valor: "aprobada", texto: "Aprobada" },
    { valor: "vencida", texto: "Vencida" },
  ],
}
