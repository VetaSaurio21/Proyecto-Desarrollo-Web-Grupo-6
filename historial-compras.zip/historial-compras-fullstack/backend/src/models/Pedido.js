import mongoose from "mongoose"
import { productoSchema } from "./Producto.js"

// Un pedido realizado por el cliente.
const pedidoSchema = new mongoose.Schema(
  {
    // Número visible del pedido (FC-0187). En la API se entrega como "id".
    codigo: { type: String, required: true, unique: true, trim: true },
    // Se guarda como texto "AAAA-MM-DD" para mostrarlo y filtrarlo tal cual,
    // sin que la zona horaria cambie el día.
    fecha: { type: String, required: true },
    entrega: { type: String, required: true },
    estado: {
      type: String,
      required: true,
      enum: ["entregado", "preparacion", "pendiente"],
    },
    productos: {
      type: [productoSchema],
      validate: [(arr) => arr.length > 0, "El pedido debe tener al menos un producto"],
    },
  },
  {
    timestamps: true,
    toJSON: {
      // Entrega al frontend { id, fecha, entrega, estado, productos }
      // y oculta los campos internos de Mongo.
      transform(_doc, obj) {
        obj.id = obj.codigo
        delete obj.codigo
        delete obj._id
        delete obj.__v
        delete obj.createdAt
        delete obj.updatedAt
        return obj
      },
    },
  }
)

export const Pedido = mongoose.model("Pedido", pedidoSchema)
