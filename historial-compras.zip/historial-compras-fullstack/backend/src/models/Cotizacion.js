import mongoose from "mongoose"
import { productoSchema } from "./Producto.js"

// Una cotización solicitada por el cliente.
const cotizacionSchema = new mongoose.Schema(
  {
    // Número visible de la cotización (COT-0044). En la API se entrega como "id".
    codigo: { type: String, required: true, unique: true, trim: true },
    fecha: { type: String, required: true },
    // Fecha hasta la que la cotización es válida ("AAAA-MM-DD").
    vigencia: { type: String, required: true },
    estado: {
      type: String,
      required: true,
      enum: ["pendiente", "aprobada", "vencida"],
    },
    productos: {
      type: [productoSchema],
      validate: [(arr) => arr.length > 0, "La cotización debe tener al menos un producto"],
    },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, obj) {
        obj.id = obj.codigo
        delete obj.codigo
        delete obj._id
        delete obj.__v
        delete obj.createdAt
        delete obj.updatedAt
        return obj
      },
    },
  }
)

export const Cotizacion = mongoose.model("Cotizacion", cotizacionSchema)
