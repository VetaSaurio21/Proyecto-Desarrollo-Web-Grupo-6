import mongoose from "mongoose"

// Subdocumento: una línea de producto dentro de un pedido o cotización.
// No lleva _id propio porque siempre vive dentro de su pedido/cotización.
export const productoSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true },
    cantidad: { type: Number, required: true, min: 1 },
    precio: { type: Number, required: true, min: 0 },
  },
  { _id: false }
)
