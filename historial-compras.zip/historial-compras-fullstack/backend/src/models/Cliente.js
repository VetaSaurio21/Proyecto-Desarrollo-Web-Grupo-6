import mongoose from "mongoose"

// Datos básicos del cliente dueño del historial.
const clienteSchema = new mongoose.Schema(
  {
    nombre: { type: String, required: true, trim: true },
  },
  {
    timestamps: true,
    toJSON: {
      transform(_doc, obj) {
        obj.id = obj._id
        delete obj._id
        delete obj.__v
        delete obj.createdAt
        delete obj.updatedAt
        return obj
      },
    },
  }
)

export const Cliente = mongoose.model("Cliente", clienteSchema)
