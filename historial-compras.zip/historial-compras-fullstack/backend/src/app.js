import express from "express"
import cors from "cors"
import morgan from "morgan"
import apiRoutes from "./routes/index.js"

// Crea y configura la aplicación de Express (sin conectar la base ni escuchar
// el puerto; de eso se encarga server.js). Separarlo así facilita las pruebas.
export function crearApp() {
  const app = express()

  // Middlewares base
  app.use(cors()) // permite que el frontend (otro puerto) llame a la API
  app.use(express.json()) // entiende cuerpos JSON en POST/PUT
  app.use(morgan("dev")) // muestra cada petición en la consola

  // Todas las rutas de la API cuelgan de /api
  app.use("/api", apiRoutes)

  // Ruta no encontrada
  app.use((req, res) => {
    res.status(404).json({ mensaje: "Ruta no encontrada" })
  })

  // Manejador de errores: cualquier throw/reject de un controlador llega acá
  app.use((err, req, res, _next) => {
    console.error(err)
    res.status(err.status || 500).json({
      mensaje: err.message || "Error interno del servidor",
    })
  })

  return app
}
