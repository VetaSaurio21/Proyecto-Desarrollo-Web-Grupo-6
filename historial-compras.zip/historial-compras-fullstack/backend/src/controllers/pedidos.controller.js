import { Pedido } from "../models/Pedido.js"
import { asyncHandler } from "../utils/asyncHandler.js"

// GET /api/pedidos  -> lista de pedidos, del más nuevo al más antiguo.
export const listarPedidos = asyncHandler(async (req, res) => {
  const pedidos = await Pedido.find().sort({ fecha: -1 })
  res.json(pedidos)
})

// GET /api/pedidos/:codigo  -> un pedido por su número (FC-0187).
export const obtenerPedido = asyncHandler(async (req, res) => {
  const pedido = await Pedido.findOne({ codigo: req.params.codigo })
  if (!pedido) {
    return res.status(404).json({ mensaje: "Pedido no encontrado" })
  }
  res.json(pedido)
})
