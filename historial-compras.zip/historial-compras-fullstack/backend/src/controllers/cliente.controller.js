import { Cliente } from "../models/Cliente.js"
import { asyncHandler } from "../utils/asyncHandler.js"

// GET /api/cliente  -> el cliente dueño del historial.
// El historial es de un solo cliente, así que se devuelve el primero.
export const obtenerCliente = asyncHandler(async (req, res) => {
  const cliente = await Cliente.findOne()
  if (!cliente) {
    return res.status(404).json({ mensaje: "No hay cliente cargado. Ejecuta el seed." })
  }
  res.json(cliente)
})
