import { Cotizacion } from "../models/Cotizacion.js"
import { asyncHandler } from "../utils/asyncHandler.js"

// GET /api/cotizaciones  -> lista de cotizaciones, de la más nueva a la más antigua.
export const listarCotizaciones = asyncHandler(async (req, res) => {
  const cotizaciones = await Cotizacion.find().sort({ fecha: -1 })
  res.json(cotizaciones)
})

// GET /api/cotizaciones/:codigo  -> una cotización por su número (COT-0044).
export const obtenerCotizacion = asyncHandler(async (req, res) => {
  const cotizacion = await Cotizacion.findOne({ codigo: req.params.codigo })
  if (!cotizacion) {
    return res.status(404).json({ mensaje: "Cotización no encontrada" })
  }
  res.json(cotizacion)
})
