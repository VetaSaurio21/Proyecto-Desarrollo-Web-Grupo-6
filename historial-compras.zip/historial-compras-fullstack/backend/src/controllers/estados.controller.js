import { estados } from "../data/seed-data.js"
import { asyncHandler } from "../utils/asyncHandler.js"

// GET /api/estados  -> { pedido: [{valor, texto}], cotizacion: [{valor, texto}] }
// Son datos de referencia (no cambian), por eso se entregan directo sin tocar la base.
export const listarEstados = asyncHandler(async (req, res) => {
  res.json(estados)
})
