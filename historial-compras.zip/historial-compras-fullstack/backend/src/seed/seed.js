import "dotenv/config"
import mongoose from "mongoose"
import { conectarDB } from "../config/db.js"
import { Pedido } from "../models/Pedido.js"
import { Cotizacion } from "../models/Cotizacion.js"
import { Cliente } from "../models/Cliente.js"
import { pedidos, cotizaciones, cliente } from "../data/seed-data.js"

// Carga los datos iniciales en MongoDB.
// Borra lo que haya y vuelve a insertar, así siempre queda igual al dataset.
async function sembrar() {
  try {
    await conectarDB(process.env.MONGODB_URI)

    await Promise.all([
      Pedido.deleteMany({}),
      Cotizacion.deleteMany({}),
      Cliente.deleteMany({}),
    ])
    console.log("Colecciones limpiadas")

    await Pedido.insertMany(pedidos)
    await Cotizacion.insertMany(cotizaciones)
    await Cliente.create(cliente)

    console.log(`Insertados: ${pedidos.length} pedidos, ${cotizaciones.length} cotizaciones, 1 cliente`)
    console.log("Seed completado")
  } catch (error) {
    console.error("Error en el seed:", error.message)
    process.exitCode = 1
  } finally {
    await mongoose.connection.close()
  }
}

sembrar()
