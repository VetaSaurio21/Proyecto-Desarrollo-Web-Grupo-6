import { Router } from "express"
import { obtenerCliente } from "../controllers/cliente.controller.js"

const router = Router()

router.get("/", obtenerCliente)

export default router
