import { Router } from "express"
import {
  listarCotizaciones,
  obtenerCotizacion,
} from "../controllers/cotizaciones.controller.js"

const router = Router()

router.get("/", listarCotizaciones)
router.get("/:codigo", obtenerCotizacion)

export default router
