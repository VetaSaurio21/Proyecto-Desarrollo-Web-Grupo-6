import { Router } from "express"
import pedidosRoutes from "./pedidos.routes.js"
import cotizacionesRoutes from "./cotizaciones.routes.js"
import clienteRoutes from "./cliente.routes.js"
import estadosRoutes from "./estados.routes.js"

const router = Router()

// Prueba rápida de que la API está viva: GET /api/health
router.get("/health", (req, res) => {
  res.json({ ok: true, servicio: "historial-compras-api" })
})

router.use("/pedidos", pedidosRoutes)
router.use("/cotizaciones", cotizacionesRoutes)
router.use("/cliente", clienteRoutes)
router.use("/estados", estadosRoutes)

export default router
