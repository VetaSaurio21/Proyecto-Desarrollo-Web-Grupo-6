import { Router } from "express"
import { listarEstados } from "../controllers/estados.controller.js"

const router = Router()

router.get("/", listarEstados)

export default router
