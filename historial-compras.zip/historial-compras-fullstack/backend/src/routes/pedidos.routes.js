import { Router } from "express"
import { listarPedidos, obtenerPedido } from "../controllers/pedidos.controller.js"

const router = Router()

router.get("/", listarPedidos)
router.get("/:codigo", obtenerPedido)

export default router
