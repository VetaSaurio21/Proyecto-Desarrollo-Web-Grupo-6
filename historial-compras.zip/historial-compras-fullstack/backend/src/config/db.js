import mongoose from "mongoose"

// Abre la conexión con MongoDB. Si falla, corta el proceso: no tiene sentido
// levantar la API sin base de datos.
export async function conectarDB(uri) {
  if (!uri) {
    throw new Error("Falta la variable MONGODB_URI en el archivo .env")
  }

  mongoose.connection.on("connected", () => {
    console.log("MongoDB conectado:", mongoose.connection.name)
  })
  mongoose.connection.on("error", (err) => {
    console.error("Error de MongoDB:", err.message)
  })

  await mongoose.connect(uri)
  return mongoose.connection
}
