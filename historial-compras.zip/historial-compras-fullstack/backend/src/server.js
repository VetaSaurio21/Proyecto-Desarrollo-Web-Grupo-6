import "dotenv/config"
import { crearApp } from "./app.js"
import { conectarDB } from "./config/db.js"

const PORT = process.env.PORT || 4000

async function iniciar() {
  try {
    // 1) Conectar a MongoDB
    await conectarDB(process.env.MONGODB_URI)

    // 2) Recién con la base lista, levantar el servidor HTTP
    const app = crearApp()
    app.listen(PORT, () => {
      console.log(`API escuchando en http://localhost:${PORT}`)
      console.log(`Prueba: http://localhost:${PORT}/api/health`)
    })
  } catch (error) {
    console.error("No se pudo iniciar el servidor:", error.message)
    process.exit(1)
  }
}

iniciar()
